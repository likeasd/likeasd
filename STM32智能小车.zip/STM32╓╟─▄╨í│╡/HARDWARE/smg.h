#ifndef __SMG_H
#define __SMG_H	

#include "stm32f10x.h"
void sdf();
#endif