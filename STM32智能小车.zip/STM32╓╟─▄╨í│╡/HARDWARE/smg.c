#include "stm32f10x.h"

void sdf()
{
	int a=0;
}